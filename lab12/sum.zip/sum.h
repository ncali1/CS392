/*******************************************************************************
* Name        : sum.h
* Author      : Nicholas Cali & Kyle Henderson
* Date        : 6/24/2021
* Description : add array using a shared library.
* Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
******************************************************************************/
#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
